@echo off
REM ============================================================================
REM UML 2.5.1 Studio & Systems Thinker Academy — Windows One-Click Starter
REM ============================================================================
cd /d "%~dp0"
echo Starting UML 2.5.1 Studio ^& Systems Thinker Academy...
start "" "%~dp0UML-Studio-Academy.html"
