#!/usr/bin/env sh
# ============================================================================
# UML 2.5.1 Studio & Systems Thinker Academy — Linux One-Click Starter
# ============================================================================
DIR="$(cd "$(dirname "$0")" && pwd)"
if command -v xdg-open >/dev/null 2>&1; then
  xdg-open "$DIR/UML-Studio-Academy.html"
elif command -v gio >/dev/null 2>&1; then
  gio open "$DIR/UML-Studio-Academy.html"
else
  echo "Please open $DIR/UML-Studio-Academy.html in your web browser."
fi
