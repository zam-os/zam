#!/bin/sh
# ============================================================================
# UML 2.5.1 Studio & Systems Thinker Academy — macOS One-Click Starter
# ============================================================================
DIR="$(cd "$(dirname "$0")" && pwd)"
open "$DIR/UML-Studio-Academy.html"
