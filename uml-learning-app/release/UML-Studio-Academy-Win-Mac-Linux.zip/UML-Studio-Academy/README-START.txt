================================================================================
  UML 2.5.1 STUDIO & SYSTEMS THINKER ACADEMY (DE / EN)
  Standalone Edition for Windows, macOS & Linux — Zero Installation Required
================================================================================

DEUTSCH — SOFORT STARTEN (KEINE INSTALLATION NÖTIG)
--------------------------------------------------------------------------------
1. Entpacke dieses ZIP-Archiv in einen beliebigen Ordner.
2. Starte die App mit einem Doppelklick:
   - Auf Windows: Doppelklick auf "UML-Studio-Academy.html"
                  (oder auf "Start-Windows.bat")
   - Auf macOS:   Doppelklick auf "UML-Studio-Academy.html"
                  (oder auf "Start-Mac.command")
   - Auf Linux:   Doppelklick auf "UML-Studio-Academy.html"
                  (oder "./start-linux.sh" ausführen)

HINWEISE:
- Es wird KEIN Server, KEIN Node.js, KEINE Installation und KEINE Internet-
  verbindung benötigt. Alles läuft 100 % lokal in deinem Browser (Chrome, Edge,
  Firefox oder Safari).
- Oben rechts in der App kannst du jederzeit umschalten zwischen:
  * Sprache:           DE (Deutsch)  |  EN (English)
  * Schwierigkeitsgrad: Level 1 (Geführt)  |  Level 2 (System-Übersetzung)
  * Modus:             Lern-Akademie  |  Freies UML Studio


ENGLISH — QUICK START (NO INSTALLATION REQUIRED)
--------------------------------------------------------------------------------
1. Extract this ZIP archive to any folder on your computer.
2. Launch the application with a double-click:
   - On Windows: Double-click "UML-Studio-Academy.html"
                 (or double-click "Start-Windows.bat")
   - On macOS:   Double-click "UML-Studio-Academy.html"
                 (or double-click "Start-Mac.command")
   - On Linux:   Double-click "UML-Studio-Academy.html"
                 (or run "./start-linux.sh")

NOTES:
- NO server, NO Node.js, NO installation, and NO internet connection required.
  Everything runs 100% locally in your modern browser (Chrome, Edge, Firefox,
  or Safari).
- In the top-right header bar you can switch at any time between:
  * Language:   DE (German)  |  EN (English)
  * Difficulty: Level 1 (Guided)  |  Level 2 (System Translation)
  * Mode:       Learning Academy  |  Free UML Studio
================================================================================
